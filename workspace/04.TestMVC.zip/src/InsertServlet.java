import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.study.BookDAO;
import com.hanul.study.BookDTO;

@WebServlet("/is.do")
public class InsertServlet extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		//클라이언트의 요청을 받는다 : 매개변수를 가져온다.
		request.setCharacterEncoding("utf-8");
		/*String title = request.getParameter("title");
		String name = request.getParameter("name");
		String isbn = request.getParameter("isbn");
		String company = request.getParameter("company");
		int cost = Integer.parseInt(request.getParameter("cost"));
		int qty = Integer.parseInt(request.getParameter("qty"));
		BookDTO dto = new BookDTO(title, name, isbn, company, cost, qty);*/
		
		BookDTO dto = new BookDTO();
		dto.setTitle(request.getParameter("title"));
		dto.setName(request.getParameter("name"));
		dto.setIsbn(request.getParameter("isbn"));
		dto.setCompany(request.getParameter("company"));
		dto.setCost(Integer.parseInt(request.getParameter("cost")));
		dto.setQty(Integer.parseInt(request.getParameter("qty")));
		
		//비지니스 로직
		BookDAO dao = new BookDAO();
		int succ = dao.inserBook(dto);
		
		//프리젠이션 로직 : html
		response.setContentType("text/html; charset=utf8");
		PrintWriter out = response.getWriter();
		if(succ > 0) {
			out.println("<script>alert('도서정보 등록성공!');</script>");
			out.println("<a href='bookMain.html'>도서정보 입력하기</a><br/><br/>");
			out.println("<a href='list.do'>전체도서 정보보기</a>");
		}else {
			out.println("<script>alert('도서정보 등록실패!');</script>");
			out.println("<a href='bookMain.html'>도서정보 입력하기</a><br/><br/>");
			out.println("<a href='list.do'>전체도서 정보보기</a>");
		}
	}
}//class









