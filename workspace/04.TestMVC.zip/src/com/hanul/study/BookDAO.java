package com.hanul.study;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BookDAO {
	private Connection conn;	//연결객체
	private PreparedStatement ps; //전송객체
	private ResultSet rs;	//결과객체
	
	//DB접속
	public Connection getConn() {
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
		String user = "hanul";
		String password = "0000";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	//동적로딩
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();	//예외발생의 원인을 상세하게 출력
			System.out.println("getConn() Exception!!!");
		}
		return conn;
	}//getConn()
	
	//DB접속 해제
	public void dbClose() {
		try {
			if(rs != null) rs.close();
			if(ps != null) ps.close();
			if(conn != null) conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}//dbClose()
	
	//도서정보 등록
	public int inserBook(BookDTO dto) {
		conn = getConn();
		String sql = "insert into tblBook values(?,?,?,?,?,?,?)";
		int succ = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getTitle());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getIsbn());
			ps.setString(4, dto.getCompany());
			ps.setInt(5, dto.getCost());
			ps.setInt(6, dto.getQty());
			ps.setInt(7, dto.getCost() * dto.getQty());
			succ = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("inserBook() Exception!!!");
		} finally {
			dbClose();
		}
		return succ;
	}//inserBook()
	
	//전체도서 목록 조회
	public ArrayList<BookDTO> searchAllBook() {
		conn = getConn();
		String sql = "select * from tblBook";
		ArrayList<BookDTO> list = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				BookDTO dto = new BookDTO();
				dto.setTitle(rs.getString("title"));
				dto.setName(rs.getString("name"));
				dto.setIsbn(rs.getString("isbn"));
				dto.setCompany(rs.getString("company"));
				dto.setCost(rs.getInt("cost"));
				dto.setQty(rs.getInt("qty"));
				dto.setPrice(rs.getInt("price"));
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("searchAllBook() Exception!!!");
		} finally {
			dbClose();
		}
		return list;
	}//searchAllBook()
	
	//도서정보 삭제
	public int deleteBook(String isbn) {
		conn = getConn();
		String sql = "delete from tblBook where isbn = ?";
		int succ= 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, isbn);
			succ = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("deleteBook() Exception!!!");
		}finally {
			dbClose();
		}
		return succ;
	}//deleteBook()
	
	
	
	
	
}//class
