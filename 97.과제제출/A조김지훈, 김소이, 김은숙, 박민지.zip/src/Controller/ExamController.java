package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.ExamDAO;
import exam.ExamVO;
import member.ExamMemberVO;


@WebServlet(urlPatterns = {"/exam","/grading"})
public class ExamController extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
			//DAO 객체를 통해서 문제를 얻어옴.
		
		if(request.getServletPath().equals("/exam")) {
			ExamDAO dao = new ExamDAO();
		List<ExamVO> list = dao.getList();
		for (ExamVO examVO : list) {
			System.out.println(examVO.getNo());
		}
		HttpSession session = request.getSession();
		session.setAttribute("list", list);
		
		RequestDispatcher rd = request.getRequestDispatcher("exam.jsp");
		rd.forward(request, response);
	}else if(request.getServletPath().equals("/grading")) {
		HttpSession session = request.getSession();
		List<ExamVO> list= (List<ExamVO>) session.getAttribute("list");

		request.setCharacterEncoding("UTF-8");
		int totalcnt = Integer.parseInt(request.getParameter("totalcnt") + "");
		for (int i = 0; i < totalcnt; i++) {
			//result 1=맞음, 0은 틀림
			try {
				if(request.getParameter((i+1)+"").equals(list.get(i).getAnswer()) ){
					list.get(i).result =1;
					list.get(i).user_result = request.getParameter((i+1)+"");
				}else {
					list.get(i).result = 0;
					list.get(i).user_result = request.getParameter((i+1)+"") == null ? "문제안품" : request.getParameter((i+1)+"");
				}
			} catch (Exception e) {
				list.get(i).result =0 ;
				list.get(i).user_result ="x";
			}
		}
		int i = 0;
		for (ExamVO vo : list) {
			if(vo.result != 0) {
				i ++;
			}
			System.out.println(vo.getNo() + "번 문제");
			System.out.println(vo.result == 0 ? "오답" : "정답" );
			System.out.println("\t사용자가 제출한 답안 : " + vo.user_result);
			System.out.println("\t실제 답안 : " + vo.getAnswer());
		
			
		}
	/*	response.setContentType("text/html; charset=utf-8"); 
		PrintWriter out = response.getWriter();
		out.println("<body>");
		out.println("<h3>당신의 점수 : "+ i*10 + "</h3>");
		out.println("<tr>");
		for(int x = 0 ; x <list.size(); x++) {
			out.println("<td>사용자가 제출한 답안 : " + list.get(x).user_result + "</td></br></br>");
			out.println("<td>실제 답안 : " + list.get(x).getAnswer() + "</td></br></br>");	
		}
		out.println("</tr>");
		out.println("<a href='index.jsp'>메인으로 돌아가기</a>");
		out.println("</body>");*/
		session.setAttribute("list", list);
		
		RequestDispatcher rd = request.getRequestDispatcher("grading.jsp");
		rd.forward(request, response);
		
		//사용자가 제출한 답안을 전부 가지고 옴
		//String 안풀었을때 null, 사용자가 답을 입력
	}

}
	
}
