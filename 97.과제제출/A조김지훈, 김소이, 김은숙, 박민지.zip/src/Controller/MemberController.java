package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.ExamMemberVO;
import member.MemberService;
import member.MemberServiceImpl;



@WebServlet(urlPatterns = {"/login","/iotlogin","/logout"})
public class MemberController extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) 
		throws ServletException, IOException {
			if(req.getServletPath().equals("/login")) {
			RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
			rd.forward(req, res);
			}
			else if(req.getServletPath().equals("/iotlogin")) {
				login(req,res);
			}
			
			else if(req.getServletPath().equals("/logout")) {
				HttpSession session = req.getSession();
				session.removeAttribute("logininfo");
				res.sendRedirect("home");
			}
			
			
			//rd.forward(req, res);
	}
	MemberServiceImpl service = new MemberServiceImpl();
	//로그인 처리
	private void login(HttpServletRequest req, HttpServletResponse res) 
		throws IOException, ServletException{
			//Mybatis를 이용해서 로그인을 처리할수있는 로직을 호출
			HashMap<String, String> map = new HashMap<>();
			map.put("name", req.getParameter("name")+"");
			map.put("id", req.getParameter("id")+"");
			ExamMemberVO vo = service.member_login(map); //map을 만들어야 함
			
			//Session (로그인, 장바구니...등등) 
			//사용자가 인터넷을 종료하기 전까지 , 톰캣서버를 리스타트 하기 전까지 유지			
			HttpSession session = req.getSession();
			req.setCharacterEncoding("UTF-8");
			PrintWriter out = res.getWriter();
			session.setAttribute("logininfo", vo);
			boolean rtnBool = vo==null ? false : true;
			out.print(rtnBool);
			
		}
	}


