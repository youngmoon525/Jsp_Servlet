package member;

import java.util.HashMap;

public class MemberServiceImpl implements MemberService {
	MemberDAO dao = new MemberDAO();


	@Override
	public ExamMemberVO member_login(HashMap<String, String> map) {
		return dao.member_login(map);
	}


}
