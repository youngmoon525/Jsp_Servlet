package member;

import java.util.HashMap;

public interface MemberService  {
	ExamMemberVO member_login(HashMap<String, String> map); //회원 로그인 처리 (select)


}
