package member;

import java.io.InputStream;
import java.util.HashMap;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MemberDAO implements MemberService {
	private static SqlSessionFactory sqlmapper; //연결객체 conn
	private static SqlSession sql; //전송과 결과를 담당하는 객체 ps,rs
	static {
		String resource = "data/SqlMapConfig.xml"; //Mybatis 설정이 있는 파일
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlmapper = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("마이바티스 SqlSessionFactory 에러 !!!");
		}
	}
	
	
	


	@Override
	public ExamMemberVO member_login(HashMap<String, String> map) {
		sql = sqlmapper.openSession();
/*		MemberVO vo = sql.selectOne("",map);
		return vo;*/
		return sql.selectOne("member.mapper.login",map);
	}
}
