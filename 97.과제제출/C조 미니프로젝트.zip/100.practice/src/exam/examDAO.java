package exam;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class examDAO {
	private static SqlSessionFactory sqlMapper;
	private static SqlSession sql;
	static {
		String resource = "data/SqlMapConfig.xml";
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlMapper = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("마이바티스 SqlSessionFactory 에러");
		}
	}
	
	public List<examVO> getList(){
		//조회건수가 1건이상이면 반환타입이 list
		sql = sqlMapper.openSession(); // 연결객체를 통해 초기화
		List<examVO> list = sql.selectList("member.mapper.exam");
		
		return list;
	}
}
