package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.memberDAO;
import member.memberVO;

@WebServlet(urlPatterns= {"/login","/join","/iotlogin","/logout","/insertmember"})
public class memberController extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd;
		if(req.getServletPath().equals("/login")) {
			rd = req.getRequestDispatcher("login.jsp");
			rd.forward(req, resp);
		}else if(req.getServletPath().equals("/join")) {
			rd = req.getRequestDispatcher("join.jsp");
			rd.forward(req, resp);
		}else if(req.getServletPath().equals("/iotlogin")) {
			login(req,resp);
		}else if(req.getServletPath().equals("/logout")) {
			HttpSession session = req.getSession();
			session.removeAttribute("logininfo");
			resp.sendRedirect("home");
		}else if(req.getServletPath().equals("/insertmember")){
			join(req,resp);
			rd = req.getRequestDispatcher("/home");
			rd.forward(req, resp);
		}
	
	}
	memberDAO dao = new memberDAO();
	private void login(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Mybatis를 이용해서 로그인을 처리할수있는 로직을 호출.
		HashMap<String, String> map = new HashMap<>();
		map.put("id", req.getParameter("id")+"");
		map.put("pw", req.getParameter("pw")+"");
		memberVO vo = dao.member_login(map);//<map을 만들어야함. (인지)
		
		
		//Session (로그인 , 장바구니 .. 등등 )
		//사용자가 인터넷을 종료하기 전까지 , 톰캣서버를 리스타트 하기 전까지
		HttpSession session = req.getSession();
		req.setCharacterEncoding("UTF-8");
		PrintWriter out = res.getWriter();
		//DB에서 정보를 조회해서 그건수가 1건이라도 있으면 회원이다.
		session.setAttribute("logininfo", vo);
		boolean rtnBool = vo==null ? false : true;
		out.print(rtnBool);
	}
	
	private void join(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//ArrayList<memberVO> list = new ArrayList<>();
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		String email = req.getParameter("email");
		
		memberVO vo1 = new memberVO();
		vo1.setId(id);
		vo1.setPw(pw);
		vo1.setEmail(email);	

		dao.member_join(vo1);
		
		//HttpSession session = req.getSession();
		//req.setCharacterEncoding("UTF-8");
		//PrintWriter out = res.getWriter();
	//	session.setAttribute("insertmember", a);
		
	}
}
