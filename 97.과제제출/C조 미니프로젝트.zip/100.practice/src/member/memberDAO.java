package member;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class memberDAO {
	private static SqlSessionFactory sqlmapper;//연결 객체 |conn
	private static SqlSession sql; //전송과 결과를 담당하는 객체 |ps , rs
	static {
		String resource = "data/SqlMapConfig.xml";//Mybatis 설정이 있는 파일
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlmapper = new SqlSessionFactoryBuilder().build(inputStream);
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("마이바티스 SqlSessionFactory 여기 에러");
		}
	}
	public memberVO member_login(HashMap<String, String> map) {
		sql = sqlmapper.openSession();
//		MemberVO vo = sql.selectOne("",map);
//		return vo; test.selectone
		return sql.selectOne("member.mapper.login",map);
	}
	public void member_join(memberVO vo1) {
		sql = sqlmapper.openSession();
		int aa = sql.insert("member.mapper.join",vo1);
		sql.commit();
		System.out.println("============");
	}
	
}
