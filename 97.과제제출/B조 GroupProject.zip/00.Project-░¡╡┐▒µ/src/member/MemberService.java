package member;

import java.util.HashMap;

public interface MemberService {
	boolean member_join(MemberVO vo);//회원가입시 회원정보를 저장한다.
	MemberVO member_login(HashMap<String, String> map);//회원 로그인 처리
	boolean member_update(MemberVO vo); //회원정보의 변경
	boolean member_delete(String id);//회원탈퇴
	boolean member_id_check(String id);//회원가입시 아이디 중복을 막는다.
									   //select count(*) from jsp_member where id = id?
	MemberVO member_selector(String id);// 회원정보 상세보기: 마이페이지(보류)
}
