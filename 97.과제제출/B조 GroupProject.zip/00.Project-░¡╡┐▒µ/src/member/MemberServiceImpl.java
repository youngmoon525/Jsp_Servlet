package member;

import java.util.HashMap;

public class MemberServiceImpl implements MemberService{
	MemberDAO dao = new MemberDAO();
	@Override
	public boolean member_join(MemberVO vo) {
		// TODO Auto-generated method stub
		return dao.member_join(vo);
	}

	@Override
	public MemberVO member_login(HashMap<String, String> map) {
		// TODO Auto-generated method stub
		return dao.member_login(map);
	}

	@Override
	public boolean member_update(MemberVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean member_delete(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean member_id_check(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public MemberVO member_selector(String id) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
