package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.MemberDAO;
import member.MemberVO;

@WebServlet("/SignUp")
public class SignUpController extends HttpServlet {

   protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("utf-8");
      MemberVO dto = new MemberVO();
      String id = request.getParameter("id");
      String pw = request.getParameter("pw");
      dto.setId(id);
      dto.setPw(pw);
      RequestDispatcher rd = request.getRequestDispatcher("member/signup_succ.jsp");
      rd.forward(request, response);
     /* System.out.println("id : "+dto.getId());
      System.out.println("pw : "+dto.getPw());*/

}
}