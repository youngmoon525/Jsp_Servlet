package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.ExamDAO;
import exam.ExamVO;

/**
 * Servlet implementation class ExamController
 */
@WebServlet(urlPatterns = { "/exam", "/grading" })
public class ExamController extends HttpServlet {

	@Override // 재정의
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		if (req.getServletPath().equals("/exam")) {  
			ExamDAO dao = new ExamDAO();
			List<ExamVO> list = dao.getList();

			HttpSession session = req.getSession();
			session.setAttribute("list", list); // Login정보처럼 사용가능하도록, Scope를 Session으로 물려놈

			RequestDispatcher rd = req.getRequestDispatcher("exam/examMain.jsp");
			rd.forward(req, res);
		} else if (req.getServletPath().equals("/grading")) {
			//Session에 물려놓은 정보를 다시 가져오기
			HttpSession session = req.getSession();// web.xml time-out
			List<ExamVO> list = (List<ExamVO>) session.getAttribute("list");
			req.setCharacterEncoding("UTF-8");
			int totalqty =Integer.parseInt(req.getParameter("totalcnt")+"");
/*			System.out.println(totalqty);
			System.out.println(list.size());*/
			int cnt = 0;
			for (int i = 0; i < totalqty; i++) {
				try {
					
						if(req.getParameter((i+1)+"").trim().equals(list.get(i).getAnswer())) {
							list.get(i).result= 1;//정답
							list.get(i).user_result = req.getParameter((i+1)+"");
						}else {
							list.get(i).result= 0;//오답
							list.get(i).user_result = req.getParameter((i+1)+"") == null ? "문제안품" : req.getParameter((i+1)+"");
						}
				} catch (Exception e) {
					list.get(i).result =0;
					list.get(i).user_result = "x";
				}
			}
			for(ExamVO dto : list) {
				System.out.println(dto.getQuestionnumber() + "번 문제");
				if(dto.result!=0) {
					cnt +=1;
				}
				System.out.println("사용자가 제출한 답안 : " + dto.user_result);
				System.out.println("정답 : " + dto.getAnswer());
			}
			
			System.out.println("맞은개수" + cnt);
			req.setAttribute("cnt", cnt);
			RequestDispatcher rd = req.getRequestDispatcher("exam/checkQuestion.jsp");
			rd.forward(req, res);
		}
	}
}
